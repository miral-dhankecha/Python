# Write a simple Python Program to INPUT two variables and print Addition, Subtraction, Multiplication and Division of both numbers.
# Miral  7161

a = int(input("Enter First Number: "))
b = int(input("Enter Second Number: "))

sum = a + b
sub = a - b
mul = a * b
div = a / b

print("Addition =", sum)
print("Subtraction =", sub)
print("Multiplication =", mul)
print("Division =", div)
