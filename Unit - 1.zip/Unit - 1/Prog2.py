# Write a program to input 2 number and an arithmetic operator. Display the result accordingly.
# Miral 7161

a = int(input("Enter Your 1st Number : "))
b = int(input("Enter Your 2nd Number : "))
op = input("Enter Operator (+, -, *, /) : ")

if op == "+":
    res = a + b
elif op == "-":
    res = a - b
elif op == "*":
    res = a * b
elif op == "/":
    res = a / b
else:
    res = "Invalid Operator"

print("Result =", res)
