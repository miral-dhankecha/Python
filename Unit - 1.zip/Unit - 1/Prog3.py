# Write a program to input Principal Amount, Rate and Year and display Simple Interest.
# Miral  7161

p = float(input("Enter Your Principal Amount : "))
r = float(input("Enter Your Rate of Interest : "))
t = float(input("Enter Your Time : "))

si = (p * r * t) / 100

print("Simple Interest =", si)
