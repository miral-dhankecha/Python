# Write a program to input Principal Amount, Rate and Year and display Compound Interest
# Miral 7161

p = float(input(" Enter Your Principal Amount : "))
r = float(input(" Enter Your Rate of Interest : "))
t = float(input(" Enter Your Time : "))

amo = p * (1 + r/100) ** t
ci = amo - p

print(" Compound Interest = ", ci)
