# Write a program to input radius of a circle, and print area of that circle.
# Miral 7161

r = float(input(" Enter Your Radius Of Circle : "))

area = 3.14 * r * r

print(" Area Of Circle = ", area)
