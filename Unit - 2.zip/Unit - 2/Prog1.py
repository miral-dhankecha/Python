# Write a program to input a number and print whether it is Even or Odd Number.
# Miral 7161

n = int(input(" Enter Your Number : "))

if n % 2 == 0:
    print(" Even Number.")
else:
    print(" Odd Number.")
