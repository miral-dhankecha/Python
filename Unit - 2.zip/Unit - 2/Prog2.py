# Write a program to input age of person and display message as follows
# - If age < 12 print You are Kid
# - If age between 12 to 17 print You are teenager
# - If age between 18 to 60 print you are Adult
# If age > 60 print You are Senior Citizen
# Miral 7161

age = int(input(" Enter Your Age : "))

if age < 12:
    print(" You Are Kid.")

elif age >= 12 and age <= 17:
    print(" You Are Teenager.")

elif age >= 18 and age <= 60:
    print(" You Are Adult.")

else:
    print(" You Are Senior Citizen.")
