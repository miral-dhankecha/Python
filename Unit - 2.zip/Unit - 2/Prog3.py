# Write a Python Program to input marks of 4 subjects and display Total, Percentage, Result and Grade. If student is fail (<40) in any subject then Result should be displayed as “FAIL” and Grade should be displayed as “With Held**”
# Miral 7161

m1 = int(input(" Enter Your Marks of Subject 1 : "))
m2 = int(input(" Enter Your Marks of Subject 2 : "))
m3 = int(input(" Enter Your Marks of Subject 3 : "))
m4 = int(input(" Enter Your Marks of Subject 4 : "))

tot = m1 + m2 + m3 + m4
per = tot / 4

print(" Total = ", tot)
print(" Percentage = ", per)

if m1 < 40 or m2 < 40 or m3 < 40 or m4 < 40:
    print(" Result = FAIL ")
    print(" Grade = With Held ")
else:
    print(" Result = PASS ")
    
    if per >= 75:
        print(" Grade = Distinction ")
    elif per >= 60:
        print(" Grade = First Class ")
    elif per >= 50:
        print(" Grade = Second Class ")
    else:
        print(" Grade = Pass Class ")
