# Write a program to input a number and display Table of that number.
# Miral 7161

n = int(input("Enter Your Number : "))

for i in range(1, 11):
    print(n, " x ", i, " = ", n * i)
