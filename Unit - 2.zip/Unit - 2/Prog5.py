# Write a program to print all numbers which are divisible by 7 between 1 to 200.
# Miral 7161

for i in range(1, 201):
    if i % 7 == 0:
        print(i)
