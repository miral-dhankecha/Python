# Demo for import module in python.
# Miral 7161

def display():
    print("Hello Miral! This is a demo of import module in Python.")
