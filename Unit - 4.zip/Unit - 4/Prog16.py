# Write a program to create list in such a way that it should add square roots of number between 1 to n in the list... At the end, the list shall be displayed. Example : [1, 4, 9, 16, 25, ....]
# Miral 7161

list = []

n = int(input(" Enter value of n : "))

for i in range(1, n+1):
    list.append(i * i)

print(" List Is :", list)
