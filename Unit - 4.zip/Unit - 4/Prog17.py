# Write a program to create dictionary in such a way that it should add number as a key and square root of number as a value between 1 to n in the dictionary... At the end, the data shall be displayed. Example : {1:1, 2:4, 3:9, 4:16, 5:25, ...}
# Miral 7161

data = {}

n = int(input(" Enter value of n : "))

for i in range(1, n+1):
    data[i] = i * i

print(" Dictionary Is :",data)
