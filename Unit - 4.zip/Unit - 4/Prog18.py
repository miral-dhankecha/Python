# Write a program which accepts a sequence of comma-separated numbers from console and generate a list and a tuple which contains every number.
# Miral 7161

val = input(" Enter Numbers Separated By Commas : ")

list = val.split(" , ")

tuple = tuple(list)

print(" List : ",list)
print(" Tuple : ",tuple)
