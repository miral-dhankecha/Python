# Write a Python Program to create a function which accepts 3 arguments. (2 numbers and one arithmetic operator). Display answer accordingly.
# Miral 7161

def calculate(a, b, op):
    if op == '+':
        print("Answer:", a + b)
    elif op == '-':
        print("Answer:", a - b)
    elif op == '*':
        print("Answer:", a * b)
    elif op == '/':
        print("Answer:", a / b)
    else:
        print("Invalid Operator")

num1 = int(input(" Enter 1st Number : "))
num2 = int(input(" Enter 2nd Number : "))
ope = input(" Enter Operator (+, -, *, /) : ")

calculate(num1, num2, ope)
