# Write a program to read names from keyboard and store into text file.
# Miral 7161

file = open("names.txt", "w")

n = int(input("How many names do you want to enter? : "))

for i in range(n):
    name = input("Enter name : ")
    file.write(name + "\n") 

file.close()

print("Names successfully written to names.txt")
