# Write a program to read any text file line by line.
# Miral 7161

filename = input("Enter File Name : ")

with open(filename, "r") as file:
    for line in file:
        print(line,end ="")

