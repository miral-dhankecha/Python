# Write a program to compute the frequency of the words from the input. The output should output after sorting the key alphanumerically. Suppose the following input is supplied to the program. “Hello There this is Python. Python is good” Then output shall be as follows :
# Hello : 1 There : 1 This : 1 is : 2 Python : 2 Good : 1
# Miral 7161

text = "Hello There this is Python. Python is Good"

# Remove punctuation and convert to lowercase
text = text.replace(".", "").replace(",", "")
words = text.split()

freq = {}

for word in words:
    word = word.capitalize()
    if word in freq:
        freq[word] += 1
    else:
        freq[word] = 1
        
for word in sorted(freq):
    print(f"{word} : {freq[word]}")
