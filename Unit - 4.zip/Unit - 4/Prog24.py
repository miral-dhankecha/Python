# Write a Python Program that creates a class with function overloading.
# Miral 7161

class Calculator:
    def addition(self,*args):
        return sum(args)

c=Calculator()
print(c.addition(5))
print(c.addition(5,10))
print(c.addition(5,10,15))
print(c.addition(5,10,15,20))
