# Demo for import module in python.
# Miral 7161

import ModualDemo

ModualDemo.display()
