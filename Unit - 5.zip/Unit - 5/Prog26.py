# 26. Python program of Barplot with all parameters of a sample data.
# Miral 7161

import matplotlib.pyplot as plt

# Sample data
categories = ['A', 'B', 'C', 'D']
values = [10, 20, 15, 25]

# Create bar plot
plt.bar(categories, values, color='skyblue', edgecolor='black', linewidth=2)

# Adding title and labels
plt.title('Bar Plot Example', fontsize=15)
plt.xlabel('Categories', fontsize=12)
plt.ylabel('Values', fontsize=12)

# Adding grid
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Show plot
plt.show()
