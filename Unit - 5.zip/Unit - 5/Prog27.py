# 27. Python program of Pie-chart with all parameters of a sample data.
# Miral 7161

import matplotlib.pyplot as plt

# Sample data
labels = ['Python', 'Java', 'C++', 'JavaScript']
sizes = [30, 25, 20, 25]
colors = ['gold', 'lightblue', 'lightgreen', 'pink']
explode = (0.1, 0, 0, 0)

# Create pie chart
plt.pie(sizes, labels=labels, colors=colors, explode=explode,
        autopct='%1.1f%%', shadow=True, startangle=140)

# Title
plt.title('Pie Chart Example')

# Equal aspect ratio ensures circle
plt.axis('equal')

# Show plot
plt.show()
