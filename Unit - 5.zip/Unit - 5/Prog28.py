# 28. Python program of Line plot with all parameters of a sample data.
# Miral 7161

import matplotlib.pyplot as plt

# Sample data
x = [1, 2, 3, 4, 5]
y = [10, 15, 20, 25, 30]

# Create line plot
plt.plot(x, y, color='blue', linestyle='--', marker='o', linewidth=2, markersize=8)

# Adding title and labels
plt.title('Line Plot Example', fontsize=15)
plt.xlabel('X Axis', fontsize=12)
plt.ylabel('Y Axis', fontsize=12)

# Adding grid
plt.grid(True)

# Show plot
plt.show()
