# 29. Python program of Box Plot with all parameters of a sample data.
# Miral 7161

import matplotlib.pyplot as plt

# Sample data
data = [10, 20, 15, 30, 25, 40, 35, 45, 50]

# Create box plot
plt.boxplot(data, notch=True, patch_artist=True,
            boxprops=dict(facecolor='lightblue', color='black'),
            whiskerprops=dict(color='black'),
            capprops=dict(color='black'),
            medianprops=dict(color='red'),
            flierprops=dict(marker='o', markerfacecolor='green', markersize=8))

# Title and labels
plt.title('Box Plot Example')
plt.ylabel('Values')

# Show plot
plt.show()
