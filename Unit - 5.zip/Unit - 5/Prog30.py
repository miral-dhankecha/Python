# 30. Python program of Scatter Plot with all parameters of a sample data.
# Miral 7161

import matplotlib.pyplot as plt

# Sample data
x = [1, 2, 3, 4, 5]
y = [5, 15, 10, 20, 25]

# Create scatter plot
plt.scatter(x, y, color='red', marker='o', s=100, edgecolors='black', alpha=0.7)

# Title and labels
plt.title('Scatter Plot Example')
plt.xlabel('X Axis')
plt.ylabel('Y Axis')

# Grid
plt.grid(True)

# Show plot
plt.show()
