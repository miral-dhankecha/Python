# Write a program to input a number and display Factorial of that number. For example, Factorial of 5 = 5 * 4 * 3 * 2 * 1 = 120.
# Miral 7161

n = int(input("Enter Your Number : "))
f = 1

for i in range(1, n + 1):
    f = f * i

print("Factorial Number Is:", f)
