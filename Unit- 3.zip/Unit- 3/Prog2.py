# Write a program to input a number and display whether number is prime or not.
# Miral 7161

n = int(input(" Enter Your Number : "))
flag=0
for i in range(2,n):
    if n%i==0:
        flag=1
        break
        
if flag==1:
    print(n," Number Is Not Prime.")
else:
    print(n," Number Is Prime.")
