# Write a program to print factorial number using function
# Miral 7161

def fact(n):
    f=1
    for i in range(1,n+1):
        f=f*i
    print("Factorial Is : ",f)

a=int(input("Enter Your Number : "))
fact(a)
